﻿namespace APITaskTime.Domain.Entities;

public class Task
{
    public Guid Id { get; set; }

    public string Name { get; set; } = null!;

    public string? Description { get; set; }

    public string Customer { get; set; } = null!;

    public ICollection<Time> Times { get; set; }
}