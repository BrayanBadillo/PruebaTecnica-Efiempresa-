﻿namespace APITaskTime.Domain.Entities;

public class Time
{
    public Guid Id { get; set; }
    public Guid Task_Id { get; set; }
    public string? Description { get; set; }

    public DateTime Begin_Date { get; set; }

    public DateTime? End_Date { get; set; }

    public Task Task { get; set; }

    public double SpentTime
    {
        get
        {
            var endDate = End_Date ?? DateTime.Now;
            return (endDate - Begin_Date).TotalHours;
        }
    }
}