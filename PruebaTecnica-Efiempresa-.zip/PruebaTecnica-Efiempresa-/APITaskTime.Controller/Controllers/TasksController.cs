﻿using APITaskTime.Application.Interfaces;
using Microsoft.AspNetCore.Mvc;

namespace APITaskTime.Controller.Controllers;

[ApiController]
[Route("[controller]")]
public class TasksController(ITaskService taskService) : ControllerBase
{
    [HttpGet("/tasks")]
    public async Task<ActionResult<IEnumerable<Domain.Entities.Task>>> GetTasks([FromQuery] bool expanded = false)
    {
        var task = await taskService.GetAllTasks(expanded);
        return Ok(task);
    }

    [HttpGet("/task/{id}")]
    public async Task<ActionResult<Domain.Entities.Task>> Task(Guid id)
    {
        var task = taskService.GetTaskById(id);
        if (task != null)
        {
            return Ok(task);
        }
        return NotFound();
    }

    [HttpPost("/tasks")]
    public async Task<ActionResult<Domain.Entities.Task>> CreateTask(Domain.Entities.Task task)
    {
        var result = await taskService.CreateTask(task);
        return CreatedAtAction(nameof(GetTasks), new { id = result.Id }, result);
    }

    [HttpDelete("/tasks/{id}")]
    public async Task<ActionResult> Tasks(Guid id)
    {
        var result = await taskService.DeleteTask(id);
        if (result)
        {
            return NoContent();
        }
        return NotFound();
    }
}