﻿using APITaskTime.Application.Interfaces;
using APITaskTime.Application.Services;
using APITaskTime.Domain.Entities;
using Microsoft.AspNetCore.Mvc;

namespace APITaskTime.Controller.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class TimesController(ITimeService timeService) : ControllerBase
    {
        [HttpGet("/tasks/{Task_Id}/times")]
        public async Task<ActionResult<IEnumerable<Time>>> GetTimes(Guid Task_Id)
        {
            var times = await timeService.GetTimesByTask_Id(Task_Id);
            return Ok(times);
        }

        [HttpPost("/tasks/{Task_Id}/times")]
        public async Task<ActionResult<Time>> PostTime(Guid Task_Id, Time time)
        {
            var createdTime = await timeService.CreateTime(Task_Id, time);
            return CreatedAtAction(nameof(GetTimes), new { Task_Id = Task_Id }, createdTime);
        }

        [HttpPut("/tasks/{Task_Id}/times/{timeId}")]
        public async Task<ActionResult<Time>> PutTime(Guid Task_Id, Guid timeId, Time time)
        {
            if (timeId != time.Id)
            {
                return BadRequest();
            }

            var updatedTime = await timeService.UpdateTime(Task_Id, time);
            if (updatedTime == null)
            {
                return NotFound();
            }
            return Ok(updatedTime);
        }

        [HttpDelete(".tasks/{Task_Id}/times/{timeId}")]
        public async Task<IActionResult> DeleteTime(Guid Task_Id, Guid timeId)
        {
            var result = await timeService.DeleteTime(Task_Id, timeId);
            if (!result)
            {
                return NotFound();
            }
            return NoContent();
        }
    }
}
