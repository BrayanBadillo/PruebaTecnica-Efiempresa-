﻿using APITaskTime.Infrastructure.Context;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;

namespace APITaskTime.Infrastructure;

public static class Extensions
{
    public static void AddDbContext(this IServiceCollection services, string connectionString) => services.AddDbContext<ApplicationDbContext>(opt => opt.UseSqlServer(connectionString));

    public static void AddServicesInfrastructure(this IServiceCollection services, string connectionString)
    {

    }
}