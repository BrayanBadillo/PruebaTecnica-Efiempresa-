﻿using APITaskTime.Domain.Entities;
using Microsoft.EntityFrameworkCore;

namespace APITaskTime.Infrastructure.Context;

public class ApplicationDbContext(DbContextOptions<ApplicationDbContext> opt) : DbContext(opt)
{
    public DbSet<Domain.Entities.Task> Tasks { get; set; }
    public DbSet<Time> Times { get; set; }


    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Domain.Entities.Task>()
            .HasKey(t => t.Id);

        modelBuilder.Entity<Time>()
            .HasKey(t => t.Id); 
        
        modelBuilder.Entity<Time>()
            .HasOne(t => t.Task)
            .WithMany(t => t.Times)
            .HasForeignKey(t => t.Task_Id);
    }
}