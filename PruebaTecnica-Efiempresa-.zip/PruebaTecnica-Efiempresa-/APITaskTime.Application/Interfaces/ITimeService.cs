﻿using APITaskTime.Domain.Entities;

namespace APITaskTime.Application.Interfaces;

public interface ITimeService
{
    Task<IEnumerable<Time>> GetTimesByTask_Id(Guid Task_Id);

    Task<Time> CreateTime(Guid Task_Id, Time time);

    Task<Time> UpdateTime(Guid Task_Id, Time time);

    Task<bool> DeleteTime(Guid Task_Id, Guid timeId);
}