﻿namespace APITaskTime.Application.Interfaces;

public interface ITaskService
{
    Task<IEnumerable<Domain.Entities.Task>> GetAllTasks(bool expanded);

    Task<Domain.Entities.Task> GetTaskById(Guid id);

    Task<Domain.Entities.Task> CreateTask(Domain.Entities.Task task);

    Task<bool> DeleteTask(Guid id);
}