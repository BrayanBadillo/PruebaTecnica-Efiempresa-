﻿using APITaskTime.Application.Interfaces;
using APITaskTime.Domain.Entities;
using APITaskTime.Infrastructure.Context;
using Microsoft.EntityFrameworkCore;

namespace APITaskTime.Application.Services;

public class TimeService(ApplicationDbContext context) : ITimeService
{
    public async Task<Time> CreateTime(Guid Task_Id, Time time)
    {
        time.Id = new Guid();
        time.Task_Id = Task_Id;
        context.Times.Add(time);
        await context.SaveChangesAsync();
        return time;

    }

    public async Task<bool> DeleteTime(Guid Task_Id, Guid timeId)
    {
        var time = await context.Times.FirstOrDefaultAsync(t => t.Id == timeId && t.Task_Id == Task_Id);
        if(time != null)
        {
            context.Times.Remove(time);
            await context.SaveChangesAsync();
            return true;
        }
        return false;
    }

    public async Task<IEnumerable<Time>> GetTimesByTask_Id(Guid Task_Id)
    {
    {
            return await context.Times.Where(t => t.Task_Id == Task_Id).ToListAsync();
    }
}

    public async Task<Time> UpdateTime(Guid Task_Id, Time time)
    {
        var exist = await context.Times.FirstOrDefaultAsync(t => t.Id == time.Id && t.Task_Id == Task_Id);
        if (exist != null)
        {
            exist.Description = time.Description;
            exist.Begin_Date = time.Begin_Date;
            exist.End_Date = time.End_Date;
            await context.SaveChangesAsync();
            return exist;
        }
        return null;
    }
}
