﻿using APITaskTime.Application.Interfaces;
using APITaskTime.Infrastructure.Context;
using Microsoft.EntityFrameworkCore;

namespace APITaskTime.Application.Services;

public class TaskService(ApplicationDbContext context) : ITaskService
{
    public async Task<Domain.Entities.Task> CreateTask(Domain.Entities.Task task)
    {
        task.Id = Guid.NewGuid();
        context.Tasks.Add(task);
        await context.SaveChangesAsync();
        return task;
    }

    public async Task<bool> DeleteTask(Guid id)
    {
        var task = context.Tasks.Include(t => t.Times).FirstOrDefault(task => task.Id == id);
        if (task != null)
        {
            context.Times.RemoveRange(task.Times);
            context.Tasks.Remove(task);
            await context.SaveChangesAsync();
            return true;
        }

        return false;
    }

    public async Task<IEnumerable<Domain.Entities.Task>> GetAllTasks(bool expanded)
    {
        if (expanded)
        {
            return await context.Tasks.Include(t => t.Times).ToListAsync();
        }
        return await context.Tasks.ToListAsync();
    }

    public async Task<Domain.Entities.Task> GetTaskById(Guid id)
    {
        return await context.Tasks.Include(t => t.Times).FirstOrDefaultAsync(t => t.Id == id);
    }
}